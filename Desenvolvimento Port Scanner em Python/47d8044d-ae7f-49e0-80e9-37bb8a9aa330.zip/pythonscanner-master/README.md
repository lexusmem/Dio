# pythonscanner
PortScanner TCP usando Python

Este projeto faz parte da aula Python para Pentesters do Professor Bruno Dias

Segue arquivo Python para conferência e utilização desde que sempre citado o autor do mesmo
